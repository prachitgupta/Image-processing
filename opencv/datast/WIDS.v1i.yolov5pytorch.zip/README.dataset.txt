# WIDS > 2023-01-29 10:44am
https://universe.roboflow.com/object-detection/wids-vngwz

Provided by a Roboflow user
License: CC BY 4.0

